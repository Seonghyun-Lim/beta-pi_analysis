% SYSTEM RELIABILITY ANALYSIS

clear probdata femodel analysisopt gfundata randomfield systems results output_filename


% Define the name and type of the file to store the output of the analysis:
% output_filename = 'outputfile_system.txt';

probdata.marg(1,:) =  [ 1 0 1 0 0 0 0 0 0];
probdata.marg(2,:) =  [ 1 0 1 0 0 0 0 0 0];

probdata.correlation = eye(2);
                     
probdata.parameter = distribution_parameter(probdata.marg);

analysisopt.ig_max = 100;
analysisopt.il_max = 5;
analysisopt.e1 = 0.001;
analysisopt.e2 = 0.001; 
analysisopt.step_code = 0;
analysisopt.grad_flag = 'DDM';
analysisopt.sim_point = 'dspt';
analysisopt.stdv_sim  = 1;
analysisopt.num_sim   = 10000;
analysisopt.target_cov = 0.05;

femodel = 0;
randomfield = 0;

for i = 1 : 2
   gfundata(i).evaluator = 'basic';
   gfundata(i).type = 'expression';
   gfundata(i).parameter = 'no';
end

gfundata(1).expression = 'x(1)^2-5*x(1)-8*x(2)+16';
gfundata(2).expression = '-16*x(1)+(x(2))^2+32';

gfundata(1).dgdq = { '2*x(1)-5'   '-8'   };
gfundata(2).dgdq = { '-16'   '2*x(2)'   };

