function PF=conditional_prob_independent(A, R, R_prime,s)

clear Z
N = 10000;
for ii = 1:10,
%x = mvnrnd(zeros(2,1),eye(2),N);
% x = mvnrnd(-R^-1*R_prime*s,R^-1*A*A'*(R^-1)',N);
%u = A^-1*R*x' + A^-1*R_prime*s*ones(1,N);
u = mvnrnd(A^-1*R_prime*s,A^-1*R*R'*(A^-1)',N);
u = u';
% Gfunction
Q(1,:) = double((u(1,:).^2 - 5*u(1,:) -8*u(2,:) + 16) < 0);
Q(2,:) = double((-16*u(1,:) + u(2,:).^2 +32) < 0);
Z(:,ii) = sum(Q,2)/N;

end

PF = mean(Z,2);
