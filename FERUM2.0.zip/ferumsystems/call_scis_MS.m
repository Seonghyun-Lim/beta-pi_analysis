function[P,COV,N] = ...
                call_scis_MS(ngf,scis_max,scis_min,cov_max,a,b,m,R)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

fid = fopen('scis_in.dat','w');

fprintf(fid,'%d\n %d\n %d\n %7.5E\n',ngf,scis_max,scis_min,cov_max);

fprintf(fid,'%10.8E %10.8E %10.8E\n',[a'; b'; m']); 

for i = 1:ngf,
   for j=i:ngf,
      fprintf(fid,'%10.8E\n',R(i,j));
   end
end

fclose(fid);
dos('scis_for.exe');

load scis_out.dat

P = scis_out(1);
COV = scis_out(2);
N = scis_out(3);

clear scis_out

%dos('del scis_in.dat');
%dos('del scis_out.dat');

   