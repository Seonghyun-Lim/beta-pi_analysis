function [ quadPoints, quadWeights ] = gaussquad(order)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


switch order
case 1
   quadPoints(1) =  0.0;
   quadWeights(1) = 2.0;
case 2
   quadPoints(1) = -0.577350269189626;
   quadPoints(2) =  0.577350269189626;
   quadWeights(1) = 1.0;
   quadWeights(2) = 1.0;
case 3
   quadPoints(1) = -0.774596669241483;
   quadPoints(2) =  0.0;
   quadPoints(3) =  0.774596669241483;
   quadWeights(1) = 0.555555555555556;
   quadWeights(2) = 0.888888888888889;
   quadWeights(3) = 0.555555555555556;
case 4
   quadPoints(1) = -0.861136311594053;
   quadPoints(2) = -0.339981043584856;
   quadPoints(3) =  0.339981043584856;
   quadPoints(4) =  0.861136311594053;
   quadWeights(1) = 0.347854845137454;
   quadWeights(2) = 0.652145154862546;
   quadWeights(3) = 0.652145154862546;
   quadWeights(4) = 0.347854845137454;
case 5
   quadPoints(1) = -0.906179845938664;
   quadPoints(2) = -0.538469310105683;
   quadPoints(3) =  0.0;
   quadPoints(4) =  0.538469310105683;
   quadPoints(5) =  0.906179845938664;
   quadWeights(1) = 0.236926885056189;
   quadWeights(2) = 0.478628670499366;
   quadWeights(3) = 0.568888888888889;
   quadWeights(4) = 0.478628670499366;
   quadWeights(5) = 0.236926885056189;
case 6
   quadPoints(1) = -0.932469514203152;
   quadPoints(2) = -0.661209386466265;
   quadPoints(3) = -0.238619186083197;
   quadPoints(4) =  0.238619186083197;
   quadPoints(5) =  0.661209386466265;
   quadPoints(6) =  0.932469514203152;
   quadWeights(1) = 0.171324492379170;
   quadWeights(2) = 0.360761573048139;
   quadWeights(3) = 0.467913934572691;
   quadWeights(4) = 0.467913934572691;
   quadWeights(5) = 0.360761573048139;
   quadWeights(6) = 0.171324492379170;
case 7
   quadPoints(1) = -0.949107912342759;
   quadPoints(2) = -0.741531185599394;
   quadPoints(3) = -0.405845151377397;
   quadPoints(4) =  0.0;
   quadPoints(5) =  0.405845151377397;
   quadPoints(6) =  0.741531185599394;
   quadPoints(7) =  0.949107912342759;
   quadWeights(1) = 0.129484966168870;
   quadWeights(2) = 0.279705391489277;
   quadWeights(3) = 0.381830050505119;
   quadWeights(4) = 0.417959183673469;
   quadWeights(5) = 0.381830050505119;
   quadWeights(6) = 0.279705391489277;
   quadWeights(7) = 0.129484966168870;
case 8
   quadPoints(1) = -0.960289856497536;
   quadPoints(2) = -0.796666477413627;
   quadPoints(3) = -0.525532409916329;
   quadPoints(4) = -0.183434642495650;
   quadPoints(5) =  0.183434642495650;
   quadPoints(6) =  0.525532409916329;
   quadPoints(7) =  0.796666477413627;
   quadPoints(8) =  0.960289856497536;
   quadWeights(1) = 0.101228536290376;
   quadWeights(2) = 0.222381034453374;
   quadWeights(3) = 0.313706645877887;
   quadWeights(4) = 0.362683783378362;
   quadWeights(5) = 0.362683783378362;
   quadWeights(6) = 0.313706645877887;
   quadWeights(7) = 0.222381034453374;
   quadWeights(8) = 0.101228536290376;
case 9
   quadPoints(1) = -0.968160239507626;
   quadPoints(2) = -0.836031107326636;
   quadPoints(3) = -0.613371432700590;
   quadPoints(4) = -0.324253423403809;
   quadPoints(5) =  0.0;
   quadPoints(6) =  0.324253423403809;
   quadPoints(7) =  0.613371432700590;
   quadPoints(8) =  0.836031107326636;
   quadPoints(9) =  0.968160239507626;
   quadWeights(1) = 0.081274388361574;
   quadWeights(2) = 0.180648160694857;
   quadWeights(3) = 0.260610696402935;
   quadWeights(4) = 0.312347077040003;
   quadWeights(5) = 0.330239355001260;
   quadWeights(6) = 0.312347077040003;
   quadWeights(7) = 0.260610696402935;
   quadWeights(8) = 0.180648160694857;
   quadWeights(9) = 0.081274388361574;
case 10
   quadPoints(1) = -0.973906528517172;
   quadPoints(2) = -0.865063366688985;
   quadPoints(3) = -0.679409568299024;
   quadPoints(4) = -0.433395394129247;
   quadPoints(5) = -0.148874338981631;
   quadPoints(6) =  0.148874338981631;
   quadPoints(7) =  0.433395394129247;
   quadPoints(8) =  0.679409568299024;
   quadPoints(9) =  0.865063366688985;
   quadPoints(10) =  0.973906528517172;
   quadWeights(1) = 0.066671344308688;
   quadWeights(2) = 0.149451349150581;
   quadWeights(3) = 0.219086362515982;
   quadWeights(4) = 0.269266719309996;
   quadWeights(5) = 0.295524224714753;
   quadWeights(6) = 0.295524224714753;
   quadWeights(7) = 0.269266719309996;
   quadWeights(8) = 0.219086362515982;
   quadWeights(9) = 0.149451349150581;
   quadWeights(10) = 0.066671344308688;
otherwise,
end
