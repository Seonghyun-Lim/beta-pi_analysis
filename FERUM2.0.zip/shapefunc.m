function [ N, dNdx, dNdy, jacobianDeterminant ] = shapefunc(nel,point,x,y);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Note: 
% The returned quantities are vectors;
% one item for each of the 4 nodes of the element

if nel == 4  % 4-node quad elements
   factor = 1/4;
   xi = point(1);
   eta = point(2);
   N(1) = factor * (1-xi) * (1-eta);
   N(2) = factor * (1+xi) * (1-eta);
   N(3) = factor * (1+xi) * (1+eta);
   N(4) = factor * (1-xi) * (1+eta);
   
   dNdxi(1) = factor * (0-1) * (1-eta);
   dNdxi(2) = factor * (0+1) * (1-eta);
   dNdxi(3) = factor * (0+1) * (1+eta);
   dNdxi(4) = factor * (0-1) * (1+eta);
   
   dNdeta(1) = factor * (1-xi) * (0-1);
   dNdeta(2) = factor * (1+xi) * (0-1);
   dNdeta(3) = factor * (1+xi) * (0+1);
   dNdeta(4) = factor * (1-xi) * (0+1);
   
   jacobianMatrix = zeros(2,2);
   
   for i = 1 : 4
      jacobianMatrix(1,1) = jacobianMatrix(1,1) + dNdxi(i)*x(i);
      jacobianMatrix(1,2) = jacobianMatrix(1,2) + dNdxi(i)*y(i);
      jacobianMatrix(2,1) = jacobianMatrix(2,1) + dNdeta(i)*x(i);
      jacobianMatrix(2,2) = jacobianMatrix(2,2) + dNdeta(i)*y(i);
   end
   
   iJac = inv(jacobianMatrix);
   
   jacobianDeterminant = det(jacobianMatrix);
   
   for i = 1 : 4
      dNdx(i) = dNdxi(i) * iJac(1,1) + dNdeta(i) * iJac(1,2);
      dNdy(i) = dNdxi(i) * iJac(2,1) + dNdeta(i) * iJac(2,2);
   end
   
else
   disp('ERROR: Do not have shape functions for this type of element yet.');
end

