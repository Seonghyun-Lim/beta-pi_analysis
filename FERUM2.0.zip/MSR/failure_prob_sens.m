function [Pf_t]=failure_prob_sens(beta,r_sens,c_sys,J_bt)

m=size(r_sens,2);
tol=10^-9; int_lb=-5; int_ub=5;
switch m
    case 1
        for i=1:size(J_bt,2);
            Pf_t(i)=quad(@(x)integrnd_sens(beta,r_sens,c_sys,J_bt(:,i),...
                x),int_lb,int_ub,tol);
        end
    case 2
        for i=1:size(J_bt,2);
            Pf_t(i)=dblquad(@(x,y)integrnd_sens(beta,r_sens,c_sys,J_bt(:,i),...
                x,y),int_lb,int_ub,int_lb,int_ub,tol);
        end
    case 3
        for i=1:size(J_bt,2);
            Pf_t(i)=triplequad(@(x,y,z)integrnd_sens(beta,r_sens,c_sys,J_bt(:,i),...
                x,y,z),int_lb,int_ub,int_lb,int_ub,int_lb,int_ub,tol);
        end
end

end
