function bound = create_bound(fixed_dof,ndfpernode,nnode) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Number of entries of fixed degrees of freedom
fixsize = size(fixed_dof);
nfix = fixsize(1);

% Loop over the fixed_dof entries and establish a list of fixed dofs
nfixeddofs = 0;
for k = 1 : nfix
   for m = 1 : ndfpernode
      if fixed_dof(k,m+1) == 1
         nfixeddofs = nfixeddofs + 1;
         node = fixed_dof(k,1);
         dof = m;
         fixed(nfixeddofs) = (node-1)*ndfpernode+dof;
      end
   end
end

% Total number of degrees of freedom
ndof = (ndfpernode*nnode);

% Initialize the boundary condition matrix
bound = zeros( ndof , ndof-nfixeddofs );

% Establish the 'bound' matrix
j = 1;            % j counts non-fixed dof's
for i = 1 : ndof  % loop over all dof's
fix_flag = 0;     % dof_flag=1 indicates a fixed dof

   for m = 1 : length(fixed)    % survey all fixed dof's to check if i is a fixed dof
      if i == (fixed(m)) 
         fix_flag = 1; % flag set to one if the i'th dof should be fixed
      end
   end
   
   if fix_flag == 1 
      j = j;           % Don't put 'one' on the diagonal if the dof is fixed 
   else
      bound(i,j) = 1;  % Put 'one' on the diagonal if the dof is free
      j = j + 1;       
   end
end

