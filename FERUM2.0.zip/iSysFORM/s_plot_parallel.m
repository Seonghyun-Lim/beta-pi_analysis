clear

tic
load formresults1
load formresults2

beta1 = formresults1.beta1;
beta2 = formresults2.beta1;


% u=[formresults1.dsptu,formresults2.dsptu];


A=[formresults1.alpha'; formresults2.alpha']
r=sqrt(A(1,:)*A(2,:)');
R=[sqrt(1-r^2),0;0,sqrt(1-r^2)]
R_prime=[r;r]
FIRST=(A^-1*R);
SECOND=(A^-1);
save improved_form_variables 

% option 1
orderofs=0;
for s=s_range
    orderofs=orderofs+1;
    prob_plot1(orderofs)=conditional_prob_parallel(A, R, R_prime,s);
end
toc
figure,
plot(s_range,prob_plot1,'r-')


% option 2
tic
orderofs=0;
for s=s_range
    orderofs=orderofs+1;
    CP=conditional_prob_independent(A, R, R_prime,s);
    p2_1(orderofs) = CP(1);
    p2_2(orderofs) = CP(2);
    prob_plot2(orderofs)=CP(1)*CP(2);     % parallel ststem
end
toc
hold on
plot(s_range,prob_plot2,'g-')

p_fo = normcdf((-beta1+r*s_range)/sqrt(1-r^2)).*normcdf((-beta2+r*s_range)/sqrt(1-r^2));
plot(s_range,p_fo,'k')

legend('True','CSI','FORM')


figure
plot(s_range,prob_plot1.*normpdf(s_range),'r-',s_range,prob_plot2.*normpdf(s_range),'g-')
hold on
plot(s_range,p_fo.*normpdf(s_range),'k-')

legend('True','CSI','FORM')

p1 = trapz(s_range, prob_plot1.*normpdf(s_range))
p2 = trapz(s_range, prob_plot2.*normpdf(s_range))

hold off
% % option 3
% tic
% orderofs=0;
% for s=s_range
%     orderofs=orderofs+1;
%     CP=conditional_prob_form(s);
%     prob_plot3(orderofs)=CP(1)*CP(2); %*normpdf(s);     % parallel ststem
% end
% toc
% hold on
% plot(s_range,prob_plot3,'k-')
% 
% xlabel('s')
% ylabel('c*p(s)*f(s)')
% legend('option 1','option 2','option 3')

