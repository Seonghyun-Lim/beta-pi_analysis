%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

probdata.marg(1,:) =  [1 0 1 0 0 0 0 0 0];
probdata.marg(2,:) =  [1 0 1 0 0 0 0 0 0];
probdata.correlation = eye(2);
probdata.parameter = distribution_parameter(probdata.marg);

analysisopt.ig_max = 100;
analysisopt.il_max = 5;
analysisopt.e1 = 0.001;
analysisopt.e2 = 0.001; 
analysisopt.step_code = 0;
analysisopt.grad_flag = 'DDM';

for i = 1 : 2
   gfundata(i).evaluator = 'basic';
   gfundata(i).type = 'expression';
   gfundata(i).parameter = 'no';
end

gfundata(1).expression = 'x(1)^2-5*x(1)-8*x(2)+16';
gfundata(2).expression = '-16*x(1)+(x(2))^2+32';

gfundata(1).dgdq = { '2*x(1)-5'   '-8'   };
gfundata(2).dgdq = { '-16'   '2*x(2)'   };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial Run
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[formresults1] = form(1,probdata,analysisopt,gfundata,0,0);
[formresults2] = form(2,probdata,analysisopt,gfundata,0,0);
rho_FORM = formresults1.alpha'*formresults2.alpha;
beta = [formresults1.beta1; formresults2.beta1];
r = [sqrt(rho_FORM); sqrt(rho_FORM)]; %DS for two components...

% c_sys = [1 0 0 0]';
% sys_type = 'parallel';
% sys_def = {2};

c_sys = [1 1 1 0]';
sys_type = 'series';
sys_def = {-2};

As = [formresults1.alpha'; formresults2.alpha'];
Qs = [sqrt(1-r(1)^2) 0; 0 sqrt(1-r(1)^2)];
Rs = [r(1); r(1)];

probdata_s.marg(1,:) =  [1 0 1 0 0 0 0 0 0];
probdata_s.marg(2,:) =  [1 0 1 0 0 0 0 0 0];
probdata_s.correlation = [1 0; 0 1];
probdata_s.parameter = distribution_parameter(probdata_s.marg);

analysisopt_s.ig_max = 100;
analysisopt_s.il_max = 5;
analysisopt_s.e1 = 0.001;
analysisopt_s.e2 = 0.001; 
analysisopt_s.step_code = 1;

[formresults_s] = form_msr_integrated(c_sys,probdata,probdata_s,analysisopt,analysisopt_s,gfundata,As,Qs,Rs);