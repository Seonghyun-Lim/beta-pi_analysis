function [sys_type,sys_event,ngf] = sys_check(system,cs_sz)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if cs_sz==[1 1],

   % Component Reliability Problem ([1],[-1],[0],[])
   if (abs(system(1,1))==1) | (system(1,1)==0) ,
      sys_type = 1;
      sys_event = 1;
      ngf = 1;
   
   % Parallel System Reliability ([7],[6],[25]...)
   elseif (sign(system(1,1))==1),
      sys_type = 2;
      sys_event = system(1,1);
      ngf = sys_event;

   % Series System Reliability ([-7],[-6],[-25]...)
   else
      sys_type = 3;
      sys_event = abs(system(1,1));
      ngf = sys_event;
   end

else % General System Reliability (Cut-set formulation)
     % ([0 -2 7 0 3 2 5 0...]: C1(-e2,e7), C2(e3,e2,e5)...
     % ([1 3 -5 0 0 2 3 9...]: C1(e1,e3,-e5), C2(e2,e3,e9)...)
     % 0's are just separating different cutsets.
     % 0's can be repeated and be placed in the first or last place.
     
   sys_type = 4;
   ngf = max(system); % Highest No. of limit-state function
   
   % Compute No. of Cutsets, ncs
   ncs = 0; 
   pre_zero = 1;
   for i = 1:length(system),
     if (system(i)~=0)&(pre_zero==1),
   	ncs = ncs+1;
	pre_zero = 0;
     elseif (system(i)==0),
        pre_zero = 1;
     end
   end
   ncs
   ngf

   sys_event = zeros(ncs,ngf); % Initialization
   ics = 0;
   pre_zero = 1;
   for i = 1:length(system),
     if (system(i)~=0)&(pre_zero==1),
        ics = ics+1;
	pre_zero = 0;
	sys_event(ics,abs(system(i))) = sign(system(i));
     elseif (system(i)~=0)&(pre_zero==0),
        sys_event(ics,abs(system(i))) = sign(system(i));
     elseif (system(i)==0),
        pre_zero = 1;
     end
   end

end