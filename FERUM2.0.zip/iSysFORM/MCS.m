clear Z
N = 100000;
for ii = 1:5000,
u = mvnrnd(zeros(2,1),eye(2),N);
u1 = u(:,1);
u2 = u(:,2);

Q = u1.^2-5*u1-8*u2+16 < 0  | -16*u1+u2.^2+32<0;
Z(ii) = sum(double(Q))/N;
end

PF = mean(Z);