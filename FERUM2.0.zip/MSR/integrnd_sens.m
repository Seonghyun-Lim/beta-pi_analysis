function int_val=integrnd_sens(beta,r_sens,c_sys,J_bt,varargin)

for i=1:length(varargin{1,1});
    for j=1:length(varargin);
        if j==1; n=i; else n=1; end
        s(j)=varargin{j}(n);
    end
    s=s';
    p_s=normcdf((-beta-r_sens*s)./sqrt(1-sum(r_sens.^2,2)));
    for k=1:length(beta);
        p_marg_mod=p_vector_mod(p_s,k);
        p(:,k)=p_marg_mod;
    end
    P_s_t=-diag(p_s)*J_bt; p_s_t=p*P_s_t;
    int_val(i,:)=c_sys'*p_s_t*mvnpdf(s);
    clear s
end

end