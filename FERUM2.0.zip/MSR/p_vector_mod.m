function [p]=p_vector_mod(p_marginals,comp_num)

    for i=1:length(p_marginals);
        if i==comp_num; 
            p_comp=1; p_comp_comp=-1;
        else
            p_comp=p_marginals(i); p_comp_comp=1-p_marginals(i);
        end
        if i==1;
            p=[p_comp; p_comp_comp];
        else
            p=[p*p_comp; p*p_comp_comp];
        end
    end

end
