

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Input
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all

probdata.marg(1,:) =  [1 0 1 0 0 0 0 0 0];
probdata.marg(2,:) =  [1 0 1 0 0 0 0 0 0];
probdata.correlation = eye(2);
probdata.parameter = distribution_parameter(probdata.marg);

analysisopt.ig_max = 100;
analysisopt.il_max = 5;
analysisopt.e1 = 0.001;
analysisopt.e2 = 0.001; 
analysisopt.step_code = 0;
analysisopt.grad_flag = 'DDM';

for i = 1 : 2
   gfundata(i).evaluator = 'basic';
   gfundata(i).type = 'expression';
   gfundata(i).parameter = 'no';
end

gfundata(1).expression = 'x(1)^2-5*x(1)-8*x(2)+16';
gfundata(2).expression = '-16*x(1)+(x(2))^2+32';

gfundata(1).dgdq = { '2*x(1)-5'   '-8'   };
gfundata(2).dgdq = { '-16'   '2*x(2)'   };

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Initial Run
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[formresults1] = form(1,probdata,analysisopt,gfundata,0,0);
[formresults2] = form(2,probdata,analysisopt,gfundata,0,0);

beta1 = formresults1.beta1;
beta2 = formresults2.beta1;

s_range=[-5:0.1:10];

A=[formresults1.alpha'; formresults2.alpha']
r=sqrt(A(1,:)*A(2,:)');
Q=[sqrt(1-r^2),0;0,sqrt(1-r^2)];
R=[r;r];

% option 1
tic
orderofs=0;
for s=s_range
    orderofs=orderofs+1;
    prob_plot1(orderofs)=conditional_prob_series(A,Q,R,s);
end
toc


% option 2
tic
orderofs=0;
for s=s_range
    orderofs=orderofs+1;
    CP=conditional_prob_independent(A,Q,R,s);
    p2_1(orderofs) = CP(1);
    p2_2(orderofs) = CP(2);
    prob_plot2(orderofs)=1-(1-CP(1))*(1-CP(2));     % series ststem
end
toc

% option 3
tic

S = inv(A)*Q*(inv(A)*Q)';
s1 = sqrt(S(1,1));
s2 = sqrt(S(2,2));
r12 = S(1,2)/s1/s2;



s_rangev = linspace(-2,5,20);
orderofs = 0;
for s=s_rangev
  orderofs = orderofs+1;
  M = inv(A)*R*s;
  probdata_n.marg(1,:) =  [ 1 M(1) s1 M(1) 0 0 0 0 0];
  probdata_n.marg(2,:) =  [ 1 M(2) s2 M(2) 0 0 0 0 0];
  probdata_n.correlation = [1 r12; r12 1];
  probdata_n.parameter = distribution_parameter(probdata_n.marg);

  [formresults1] = form(1,probdata_n,analysisopt,gfundata,0,0);
  [formresults2] = form(2,probdata_n,analysisopt,gfundata,0,0);
  
  prob_plot3(orderofs) = 1-(1-formresults1.pf1)*(1-formresults2.pf1);
  Mv1(orderofs) = M(1);
  Mv2(orderofs) = M(2);
  pf1v(orderofs) = formresults1.pf1;
  pf2v(orderofs) = formresults2.pf1;
    
end

toc

p_fo = 1-(1-normcdf((-beta1+r*s_range)/sqrt(1-r^2))).*(1-normcdf((-beta2+r*s_range)/sqrt(1-r^2)));

figure(1)
plot(s_range,prob_plot1,'r-',s_range,prob_plot2,'g-',s_rangev,prob_plot3,'b:',s_range,p_fo,'k')
legend('True','CSI','DS-FORM','FORM')

figure(2)
plot(s_range,prob_plot1.*normpdf(s_range),'r-', ... 
    s_range,prob_plot2.*normpdf(s_range),'g-', ...
    s_rangev,prob_plot3.*normpdf(s_rangev),'b:', ...
    s_range,p_fo.*normpdf(s_range),'k-')
legend('True','CSI','DS-FORM','FORM')

p1 = trapz(s_range, prob_plot1.*normpdf(s_range))
p2 = trapz(s_range, prob_plot2.*normpdf(s_range))
p3 = trapz(s_rangev, prob_plot3.*normpdf(s_rangev))
pFORM = trapz(s_range, p_fo.*normpdf(s_range))
