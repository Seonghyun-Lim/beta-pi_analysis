function[pf_sys,beta_sys,Nscis,covscis]=...
  sys_rel(sys_type,beta_form,alpha,sys_event,ngf,scis_max,scis_min,cov_max)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

sigma = 1.0e-4;

% Construct Correlation Matrix, R
   for i = 1:ngf,
     R(i,i) = 1;
     for j = 1:i-1,
       R(i,j) = alpha(:,i)'*alpha(:,j);
       R(j,i) = R(i,j); 
     end
   end

if (sys_type == 2), % Parallel System

   a = beta_form;
   b = 8.12635811919617*ones(size(beta_form));
   m = zeros(size(beta_form));

   if cond(R)>= 1/eps,
     [R]=noise_deg(R,sigma);
   end

   [pf_sys,covscis,Nscis]=call_scis_MS(ngf,scis_max,scis_min,cov_max,a,b,m,R);
   beta_sys = -inv_norm_cdf(pf_sys);
   
elseif (sys_type == 3), % Series System

   a = -8.12635811919617*ones(size(beta_form));
   b = beta_form;
   m = zeros(size(beta_form));

   if cond(R)>= 1/eps,
     [R]=noise_deg(R,sigma);
   end
   cond(R)

   [pf_sys,covscis,Nscis]=call_scis_MS(ngf,scis_max,scis_min,cov_max,a,b,m,R);
   pf_sys = 1 - pf_sys;
   beta_sys = -inv_norm_cdf(pf_sys);

elseif (sys_type == 4), % General System Reliability Problem
                        % Solve Cut-set Formulation w/ Bimodal Bounds

  size_sys_event = size(sys_event);
  ncs = size_sys_event(1,1);

  njc = nchoosek(ncs,2);

  for ics = 1:ncs,
     disp(['Cutset: ' int2str(ics)])

     %------- Extract correlation matrix,bounds for selected cutset -------%
     %------- Estimate multinormal probability of single cutset     -------%
     [n1,a1,b1,R1]=ev_ext(sys_event(ics,:),beta_form,R);
     if cond(R1)>= 1/eps,[R1]=noise_deg(R1,sigma);end
     [Ps(ics),covscis(ics,ics),Nscis(ics,ics)]=...
      call_scis_MS(n1,scis_max,scis_min,cov_max,a1,b1,zeros(n1,1),R1);
             
     for ijc = 1:ics-1,
        disp(['Joint of Cutsets ' int2str(ics) ' and ' int2str(ijc)])
        %------- Skip joint of two cutsets if it's null event -------%
        if prod(sys_event(ics,:).*sys_event(ijc,:) + ones(1,ngf)) == 0,
           Pj(ics,ijc) = 0;
           disp(['>>> Joint of cutset ' int2str(ics) ' and ' int2str(ijc)...
               ' compose null event - Skipped <<<'])
        else
           %------- Extract correlation matrix,bounds for selected joint of cutsets --%
           %------- Estimate multinormal probability of joint of two cutsets        --%
           tmp = sign(sys_event(ics,:)+sys_event(ijc,:));
           [n1,a1,b1,R1]=ev_ext(tmp,beta_form,R);
           if cond(R1)>= 1/eps,
	      [R1]=noise_deg(R1,sigma);
	   end
           cond(R1)
	   [Pj(ics,ijc),covscis(ics,ijc),Nscis(ics,ijc)]=...
               call_scis_MS(n1,scis_max,scis_min,cov_max,a1,b1,zeros(n1,1),R1);
        end
     end % ijc
   end % ics

   % Bimodal Bounds
   %     - Calculate bounds of probability based on Ditlevsen's Bi-modal bounds        
   %       (not relaxed)                                                               


   %------- Bounds of failure probability -------%
   pf_sys(1) = sum(max(Ps-sum(Pj'),0));
   pf_sys(2) = sum(Ps) - sum(max(Pj'));

   %------- Bounds of reliability index -------%
   beta_sys(2) = -inv_norm_cdf(pf_sys(1));
   beta_sys(1) = -inv_norm_cdf(pf_sys(2));
   
   disp([' '])
   disp(['.................................................'])
   disp(' Failure Probability of the General System exists between'),disp(pf_sys(1)),disp(' and '),disp(pf_sys(2))
   disp(' Corresponding Reliability Index exists between          '),disp(beta_sys(1)),disp(' and '),disp(beta_sys(2))
   disp(['.................................................'])
   disp('The following parameters are now available in your current workspace:')
   disp('   Nscis(i,j)   = Actual Number of iterations of SCIS algorithm for P(C_i*C_j)')
   disp('   covscis(i,j) = Actual Coefficient of Variation of SCIS algorithm for P(C_i*C_j)')
   disp(['.................................................'])
   disp([' '])

end % if

