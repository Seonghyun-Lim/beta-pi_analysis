function systemsresults = systems(probdata,analysisopt,gfundata,femodel,randomfield,system)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Extract information about the system
scis_max = system.scis_max;
scis_min = system.scis_min;
cov_max  = system.cov_max;
system   = system.system;

% Extract other information
i_max = analysisopt.ig_max;

% Find the size of the systems definition vector
cs_sz = size(system);

% Display error message if the 'system' vector is not a vector
if (cs_sz(1,1)~=1),
   disp('.......................................................');
   disp('ERROR: THE INPUT(system) SHOULD BE SCALAR OR ROW VECTOR');
   disp('.............................................. ........');
   return
end

% Preparation for systems reliability analysis
[sys_type,sys_event,ngf] = sys_check(system,cs_sz);

% Initialize matrices to store gfun-values and step sizes
gfcn = zeros(i_max,ngf);
stpsz = zeros(i_max-1,ngf);

% Loop over all limit-state functions
for igf = 1:ngf,
   
   % Open figure window for plot of deformed structure (FERUMlinearfecode)
   gfunevaluator = lower(gfundata(igf).evaluator)
   switch gfunevaluator
   case 'ferumlinearfecode'
      figure(igf);
   otherwise
   end
   
   % Run FORM analysis
   formresults = form(igf,probdata,analysisopt,gfundata,femodel,randomfield);
   iter_c       = formresults.iter;
   beta_form_c  = formresults.beta1;
   pf1_c        = formresults.pf1;
   dsptu_c      = formresults.dsptu;
   alpha_c      = formresults.alpha;
   dsptx_c      = formresults.dsptx;
   imptg_c      = formresults.imptg;
   gfcn_c       = formresults.gfcn;
   stpsz_c      = formresults.stpsz;
      
   % Display results
   disp('Number of iterations:'),disp(iter_c)
   disp('Reliability index beta:'),disp(beta_form_c)
   disp('Failure probability:'),disp(pf1_c)
   
   % Store results
   iter(igf,1)      = iter_c;
   beta_form(igf,1) = beta_form_c;
   pf1(igf,1)       = pf1_c;
   dsptu(:,igf)   = dsptu_c;
   alpha(:,igf)   = alpha_c;
   dsptx(:,igf)   = dsptx_c';
   imptg(:,igf)   = imptg_c;
   gfcn(1:length(gfcn_c),igf) = gfcn_c';
   stpsz(1:length(stpsz_c),igf) = stpsz_c';
   
end

gfcn = gfcn(1:max(iter),:);
stpsz = stpsz(1:max(iter)-1,:);


% System Reliability Analysis (If necessary)

if sys_type == 1,   % Component Reliability Analysis - Done
   disp('  Component reliability analysis was chosen, or')
   disp('  No system reliability analysis was specified in input file')
else % System Reliability Analysis
   if exist('scis_max')==0,
      scis_max = 20000;
   end
   if exist('scis_min')==0,
      scis_min = 1000;
   end
   if exist('cov_max')==0,
      cov_max = 0.05;
   end
   [pf_sys,beta_sys,Nscis,covscis] = ...
      sys_rel(sys_type,beta_form,alpha,sys_event,ngf,scis_max,scis_min,cov_max);
end

% Assign values to output
systemsresults.pf       = pf_sys;
systemsresults.beta     = beta_sys;
systemsresults.Nscis    = Nscis;
systemsresults.covscis  = covscis;

systemsresults.iter      = iter;
systemsresults.beta_form = beta_form;

systemsresults.pf1       = pf1;
systemsresults.dsptu     = dsptu;
systemsresults.alpha     = alpha;
systemsresults.dsptx     = dsptx; 
systemsresults.imptg     = imptg;
systemsresults.gfcn      = gfcn;
systemsresults.stpsz     = stpsz;
