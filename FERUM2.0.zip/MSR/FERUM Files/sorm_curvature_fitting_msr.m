function sorm_curfit_results = sorm_curvature_fitting_msr(c_sys,beta,r,formresults,probdata)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% This function compute an approximation of the probability of failure % 
% using the curvature-fitting method                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%    i_complex = sqrt(-1);
 
   iter = formresults.iter;
   beta_form = formresults.beta1;
   pf1 = formresults.pf1;
   dsptu = formresults.dsptu;
   alpha = formresults.alpha;
   dsptx = formresults.dsptx';
%    imptg = formresults.imptg;
%    gfcn = formresults.gfcn;
%    stpsz = formresults.stpsz;
   
   
   marg      = probdata.marg;
   R         = probdata.correlation;
      
    % Determine number of random variables
	marg_dim = size(marg,1);

	% Compute corrected correlation coefficients
	Ro = mod_corr( probdata, R );

	% Cholesky decomposition
	Lo = (chol(Ro))';
   	iLo = inv(Lo);
   
   	J_u_x = jacobian(dsptx,dsptu,probdata,Lo,iLo);
   	J_x_u = inv(J_u_x);
%    	[ G, grad_g ] = gfun(lsf,dsptx,grad_flag,probdata,gfundata,femodel,randomfield);
    [G,grad_g]=msr_lsf(dsptx,c_sys,beta,r);
   	grad_G = (grad_g * J_x_u)';   % Gradient of G evaluate at the design point

   
   % Compute the rotation matrix
   R1 = gram_schmidt(alpha');
   
   % Compute the hessian matrix....
%    hess_G = hessian_G_msr(1,dsptx,dsptu,G,probdata,gfundata,femodel,randomfield);
   hess_G = hessian_G_msr(c_sys,beta,r,dsptu,G,probdata);
   
   A = R1*hess_G*R1' / norm(grad_G);

   [eigenvectors,D] = eig(A([1:(marg_dim-1)],[1:(marg_dim-1)]));
   
   for i=1:marg_dim-1
      kappa(i) = D(i,i);
   end
  
   %[V,D] = EIG(X) produces a diagonal matrix D of eigenvalues and a
   %full matrix V whose columns are the corresponding eigenvectors so
   %that X*V = V*D.

% Breitung
pf2_breitung = ferum_cdf(1,-beta_form,0,1) * prod(1./(1+beta_form*kappa).^0.5);
beta2_breitung = -inv_norm_cdf(pf2_breitung);

% Breitung modified by Hohenbichler / Rackwitz
kk = ferum_pdf(1,beta_form,0,1) / ferum_cdf(1,-beta_form,0,1);
pf2_breitung_mod = ferum_cdf(1,-beta_form,0,1) * prod(1./(1+kk*kappa).^0.5);
beta2_breitung_mod = -inv_norm_cdf(pf2_breitung_mod);

% Tvedt three-term approximation
% A1 = ferum_cdf(1,-beta,0,1) * prod(1./(1+beta*kappa).^0.5);
% A2 = (beta*ferum_cdf(1,-beta,0,1) - ferum_pdf(1,beta,0,1))*(prod(1./(1+beta*kappa).^0.5)-prod(1./(1+(beta+1)*kappa).^0.5));
% A3 = (beta+1)*(beta*ferum_cdf(1,-beta,0,1) - ferum_pdf(1,beta,0,1))*(prod(1./(1+beta*kappa).^0.5)-real(prod(1./(1+(beta+i_complex)*kappa).^0.5)));
% pf2_tvedt = A1 + A2 + A3;
% beta_tvedt = -inv_norm_cdf(pf2_tvedt);

% Tvedt exact integral formula using saddle-point method and trapezoidale rule
us = saddle_point(beta_form,kappa);
pf2_tvedt_EI = pf2_Tvedt_EI(us,beta_form,kappa);
beta2_tvedt_EI = -inv_norm_cdf(pf2_tvedt_EI);  

% SORM Post-processing
   
   	% FORM results
   	sorm_curfit_results.iter = iter;                                % Number_of_iterations in FORM analysis
   	sorm_curfit_results.beta1 = beta_form;                                % Reliability_index_beta FORM analysis
   	sorm_curfit_results.pf1 = pf1;                  				% Failure_probability_pf1   
        
    % SORM results
    sorm_curfit_results.R1 = R1;									 % Rotation matrix 
    sorm_curfit_results.hess_G = hess_G;                             % Hessian of G evaluated at the design point
    sorm_curfit_results.kappa = kappa';                              % Curvatures in the (n-1)(n-1) space
    sorm_curfit_results.eig_vectors=eigenvectors;                    % Matrix of eigenvectors
    sorm_curfit_results.beta2_breitung = beta2_breitung;             % Reliability index beta2  according to Breitung formula 
   	sorm_curfit_results.pf2_breitung = pf2_breitung;                 % Failure probability pf2  according to Breitung formula
    sorm_curfit_results.beta2_breitung_mod = beta2_breitung_mod;     % Reliability index beta2  according to improved  Breitung formula 
   	sorm_curfit_results.pf2_breitung_mod = pf2_breitung_mod;         % Failure probability pf2  according to improved Breitung formula
    sorm_curfit_results.beta2_tvedt_EI = beta2_tvedt_EI;             % Reliability index beta2  according to Tvedt exact integral formula 
   	sorm_curfit_results.pf2_tvedt_EI = pf2_tvedt_EI;                 % Failure probability pf2  according to Tvedt exact integral formula

    
  
