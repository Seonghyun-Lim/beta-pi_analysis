function[n1,a1,b1,R1]=ev_ext(evset,beta_s,R)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%EV_EXT    Event Extraction
%
%   [n1,a1,b1,R1]=ev_ext(evset,beta_s,R)
%
%   Extract bounds vectors, correlation matrix corresponding to
%   selected events
%
%   Input parameters:
%      evset  = Matrix indicating the events involved in given cutset
%               (1: involved, 0: not involved, -1: compliment involved)
%      beta_s = Original reliability indices vector
%      R      = Original correlation matrix
%
%   Output parameters:
%      n1 = number of events involved(or compliment involved) in given cutset
%      a1 = extracted lower bounds
%      b1 = extracted upper bounds
%      R1 = extracted correlation matrix
%
%   Note:
%      For stability of numerical analysis, 8.12635811919617 and -8.12635811919617
%      are used instead of inf and -inf
%      

% Original no. of random variables
n = length(beta_s);

% Extracting bound vectors
iae = 1;
for i = 1:n,
   if evset(i) == -1,
      a1(iae) = -8.12635811919617;
      b1(iae) = beta_s(i);
      iae = iae + 1;
   elseif evset(i) == 1,
      a1(iae) = beta_s(i);
      b1(iae) = 8.12635811919617;
      iae = iae + 1;
   end
end

% Calculating No. of events involved in the present cutset
n1 = iae - 1;

% Extracting Modal Correlation Coefficient Matrix
R1 = zeros(n1,n1);
ir = 1;
for i = 1:n,
   if evset(i) ~= 0,
      R1(ir,ir) = 1;
      ic = 1;
      for j = 1:i-1,
         if evset(j) ~= 0,
            R1(ir,ic)= R(i,j);
            R1(ic,ir)=R1(ir,ic);
            ic = ic+1;
         end
      end
   ir = ir+1;   
   end
end

a1 = (a1(1,1:n1))';
b1 = (b1(1,1:n1))';



