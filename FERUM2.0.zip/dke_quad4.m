function dke = dke_quad4(nodalcoords,parameterlist,parameter) 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% EXTRACT DATA FROM PARAMETERLIST
E     = parameterlist(1);
nu    = parameterlist(2);
thick = parameterlist(3);
ps    = parameterlist(4); % (1:plane strain, 2: plane stress)

% EXTRACT NODAL COORDINATES
x = [ nodalcoords(1) nodalcoords(3) nodalcoords(5) nodalcoords(7) ];
y = [ nodalcoords(2) nodalcoords(4) nodalcoords(6) nodalcoords(8) ];

% SOME INITIAL DECLARACTIONS
nel = 4;
order = 2;

% MATRIX OF ELASTIC CONSTANTS
de = zeros( 3 );
if parameter == 6
   if ps == 1  % Plane strain 
      mju = 2 * E * nu * ( 2 - nu ) / ( ( 1 - 2 * nu ) * ( 1 + nu ) )^2;
      lambda = -1 * E / ( 2*( 1 + nu )^2 );
      dummy = E * ( 1 + 2*nu^2 ) / ( ( 1 - 2 * nu ) * ( 1 + nu ) )^2;
      de(1,1) = mju;
      de(1,2) = dummy;
      de(2,1) = dummy;
      de(2,2) = mju;
      de(3,3) = lambda;
      
   else % Plane stress
      mju = 2 * E * nu / ( 1 - nu^2 )^2;
      lambda = E * ( 1 + nu^2 ) / ( 1 - nu^2 )^2;
      dummy = -1 * E / ( 2*( 1 + nu )^2 );
      de(1,1) = mju;
      de(1,2) = lambda;
      de(2,1) = lambda;
      de(2,2) = mju;
      de(3,3) = dummy;
   end
else
   if parameter == 2
      E = 1;
   elseif parameter == 7
      thick = 1;
   end
   if ps == 1  % Plane strain 
      mju = E * ( 1 - nu ) / ( ( 1 - 2 * nu ) * ( 1 + nu ) );
      lambda = nu / ( 1 - nu );
      dummy = ( 1 - 2*nu ) / ( 2 * ( 1 - nu ) );
      de(1,1) = mju;
      de(1,2) = mju * lambda;
      de(2,1) = mju * lambda;
      de(2,2) = mju;
      de(3,3) = mju * dummy;
      
   elseif ps == 2 % Plane stress
      mju = E / ( 1 - nu^2 );
      lambda = ( 1 - nu ) / 2;
      de(1,1) = mju;
      de(1,2) = mju * nu;
      de(2,1) = mju * nu;
      de(2,2) = mju;
      de(3,3) = mju * lambda;
   else
      disp('ERROR: No other options than plane strain or plane stress');
   end
end
materialtangent = de;

% QUADRATURE RULE
[ quadPoints, quadWeights ] = gaussquad(order);

% LOOP OVER QUADRATURE POINTS
elementtangent = zeros(8,8);
internalforces = zeros(8,1);
k = 1;
for i = 1 : order
   for j = 1 : order
      
      % COORDINATES AND WEIGHTS FOR THIS POINT (Cheat a bit for now: use only second order rule)
      if (order==2)
         if (k==1)
            point  = [ quadPoints(2),  quadPoints(2)  ];
            weight = [ quadWeights(2), quadWeights(2) ];
         elseif(k==2)
            point  = [ quadPoints(1),  quadPoints(2)  ];
            weight = [ quadWeights(1), quadWeights(2) ];
         elseif(k==3)
            point  = [ quadPoints(1),  quadPoints(1)  ];
            weight = [ quadWeights(1), quadWeights(1) ];
         elseif(k==4)
            point  = [ quadPoints(2),  quadPoints(1)  ];
            weight = [ quadWeights(2), quadWeights(1) ];
         end
      else
         disp('Cannot handle this integration order yet!')
      end
      
      % GET SHAPE FUNCTIONS, DERIVATIVES AND JACOBIAN AT THIS QUADRATURE POINT
      [ N, dNdx, dNdy, jacDet ] = shapefunc(nel,point,x,y);
      
      % STRAIN-DISPLACEMENT MATRIX (B)
      for kk = 1 : nel
         bb(1,(2*kk-1)) = dNdx(kk);
         bb(2,(2*kk-1)) = 0;
         bb(3,(2*kk-1)) = dNdy(kk);
         
         bb(1,(2*kk  )) = 0;
         bb(2,(2*kk  )) = dNdy(kk);
         bb(3,(2*kk  )) = dNdx(kk);  
      end
      
      % PRE-COMPUTE JACOBIAN TIMES QUADRATURE WEIGHT (VOLUME CHANGE)
      dvol = jacDet * prod(weight) * thick;
      
      % COMPUTE TANGENT STIFFNESS
      elementtangent = elementtangent + bb' * materialtangent * bb * dvol;
      
      k = k+1;
   end
end

dke = elementtangent;