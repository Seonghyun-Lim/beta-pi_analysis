function [G,grad_g,As_new,Qs_new,Rs_new]=msr_lsf_int_SORM(s,c_sys,probdata,analysisopt,gfundata,As,Qs,Rs)

h = 1/200;

M = inv(As)*Rs*s(1);
S = inv(As)*Qs*(inv(As)*Qs)';
s1 = sqrt(S(1,1));
s2 = sqrt(S(2,2));
r12 = S(1,2)/s1/s2;

probdata.marg(1,:) =  [ 1 M(1) s1 M(1) 0 0 0 0 0];
probdata.marg(2,:) =  [ 1 M(2) s2 M(2) 0 0 0 0 0];
probdata.correlation = [1 r12; r12 1];
probdata.parameter = distribution_parameter(probdata.marg);

[formresults1] = form(1,probdata,analysisopt,gfundata,0,0);
[formresults2] = form(2,probdata,analysisopt,gfundata,0,0);
[sorm_curfit_results1] = sorm_curvature_fitting(1,formresults1,probdata,analysisopt,gfundata,0,0);
[sorm_curfit_results2] = sorm_curvature_fitting(2,formresults2,probdata,analysisopt,gfundata,0,0);

% p_marginals= [formresults1.pf1; formresults2.pf1];
p_marginals = [sorm_curfit_results1.pf2_breitung; sorm_curfit_results2.pf2_breitung];
p=prob_vector(p_marginals);
G=s(2)-norminv(c_sys'*p);

rho_FORM = formresults1.alpha'*formresults2.alpha;
beta = [formresults1.beta1; formresults2.beta1];
r = [sqrt(rho_FORM); sqrt(rho_FORM)]; %DS for two components...

As_new = [formresults1.alpha'; formresults2.alpha'];
Qs_new = [sqrt(1-r(1)^2) 0; 0 sqrt(1-r(1)^2)];
Rs_new = [r(1); r(1)];

Mp = inv(As)*Rs*(s(1)+h);
probdata.marg(1,:) =  [ 1 Mp(1) s1 Mp(1) 0 0 0 0 0];
probdata.marg(2,:) =  [ 1 Mp(2) s2 Mp(2) 0 0 0 0 0];

[formresults1] = form(1,probdata,analysisopt,gfundata,0,0);
[formresults2] = form(2,probdata,analysisopt,gfundata,0,0);
[sorm_curfit_results1] = sorm_curvature_fitting(1,formresults1,probdata,analysisopt,gfundata,0,0);
[sorm_curfit_results2] = sorm_curvature_fitting(2,formresults2,probdata,analysisopt,gfundata,0,0);

%p_marginals= [formresults1.pf1; formresults2.pf1];
p_marginals = [sorm_curfit_results1.pf2_breitung; sorm_curfit_results2.pf2_breitung];
p=prob_vector(p_marginals);
G_a_step_ahead = s(2)-norminv(c_sys'*p);

grad_g(1) = (G_a_step_ahead - G)/h;
grad_g(2) = 1;

% for i=1:length(beta);
%     p_marg_mod=p_vector_mod(p_marginals,i);
%     P_h(:,i)=p_marg_mod;
% end
% dP_ds=diag(normpdf((-beta+r*s(1:end-1))./sqrt(1-sum(r.^2,2)))./...
%     sqrt(1-sum(r.^2,2)))*r;
% dp_ds=P_h*dP_ds;
% grad_g=[-c_sys'*dp_ds*1/(normpdf(s(end)-G)) 1];

end

