function [femodel,rf_jacobian]=position(x,femodel)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% Extract finite element model data
id           = femodel.id;
loading      = femodel.loading;
el           = femodel.el;
node         = femodel.node;
nodal_spring = femodel.nodal_spring;

% Determin problem size
iddim = size(id);
nid = iddim(1);  
eldim = size(el);
nel = eldim(1);

for i = 1 : nid % Go through id-array and position r.v.'s into FEM model
   
   rv_numb = id(i,1);
   
   % Position nodal load
   if id(i,2) == 1
      loading( id(i,3) , 2 ) = loading( id(i,3) , 4 ) * x(rv_numb);
      
      % Position nodal spring stiffness
   elseif id(i,2) == 5
      nodal_spring( id(i,3) , 2 ) = x(rv_numb);
      
      % Position Young's modulus
   elseif id(i,2) == 2
      eltype = el(id(i,3),1);
      if     (eltype==1) 
         el( id(i,3) , 4 ) = x(rv_numb); 
      elseif (eltype==2)
         el( id(i,3) , 4 ) = x(rv_numb); 
      elseif (eltype==3)
         el( id(i,3) , 6 ) = x(rv_numb); 
      elseif (eltype==4)
         el( id(i,3) , 4 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 6 ) = x(rv_numb); 
      end
      
      % Position moment of inertia
   elseif id(i,2) == 3
      eltype = el(id(i,3),1);
      if (eltype==2)
         el( id(i,3) , 5 ) = x(rv_numb); 
      end
      
      % Position cross-sectional area
   elseif id(i,2) == 4
      eltype = el(id(i,3),1);
      if     (eltype==1) 
         el( id(i,3) , 5 ) = x(rv_numb); 
      elseif (eltype==2)
         el( id(i,3) , 6 ) = x(rv_numb); 
      elseif (eltype==4)
         el( id(i,3) , 5 ) = x(rv_numb); 
      end
      
      % Position Poisson's ratio
   elseif id(i,2) == 6
      eltype = el(id(i,3),1);
      if (eltype==3)
         el( id(i,3) , 7 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 7 ) = x(rv_numb); 
      elseif (eltype==4)
         el( id(i,3) , 6 ) = x(rv_numb); 
      end
      
      % Position thickness of 2D elements
   elseif id(i,2) == 7
      eltype = el(id(i,3),1);
      if (eltype==3)
         el( id(i,3) , 8 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 8 ) = x(rv_numb); 
      end
      
      % Position yield limit on stress
   elseif id(i,2) == 8
      eltype = el(id(i,3),1);
      if (eltype==4)
         el( id(i,3) , 7 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 9 ) = x(rv_numb); 
      end
      
      % Position isotropic hardening parameter
   elseif id(i,2) == 9
      eltype = el(id(i,3),1);
      if (eltype==4)
         el( id(i,3) , 8 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 10 ) = x(rv_numb); 
      end
      
      % Position kinematic hardening parameter
   elseif id(i,2) == 10
      eltype = el(id(i,3),1);
      if (eltype==4)
         el( id(i,3) , 9 ) = x(rv_numb); 
      elseif (eltype==5)
         el( id(i,3) , 11 ) = x(rv_numb); 
      end
      
   end
   
end

% Put data back into finite element model
femodel.loading      = loading;
femodel.el           = el;
femodel.nodal_spring = nodal_spring;
