% clear; clc; close all

% beta=(4*(1:10)'-22)/9;
beta=0*ones(6,1);
% p_marg=normcdf(-(4*(1:10)'-22)/9);
% sys_def={[0 0 -1 5 3 0 0 1 2 0 -5 -6 -7 10 0 0 0],'cut'}; 
% sys_def={10};
% sys_def={-6}; 
sys_def={[1 2 0 3 4 0 5 6],'lINk'}; 
% integ_method='SORM'; SORM_method='point fitting'; point_fitted_method='Newton';

% R=0.5*ones(10); R=R-diag(diag(R))+eye(10);
% R(1,5)=0.4; R(2,4)=0.4; R(1,7)=0.9; R(2,6)=0.9; R(3,5)=0.9;
% R(5,1)=0.4; R(4,2)=0.4; R(7,1)=0.9; R(6,2)=0.9; R(5,3)=0.9;
% R=tril(R);

rr=sqrt((13-2*(1:6)')/12); R=rr*rr'; R=R-diag(diag(R))+eye(length(R));
R=tril(R);

% J_Pft=[1 1; 1 1; 1 1; 1 1; 1 1; 1 1];