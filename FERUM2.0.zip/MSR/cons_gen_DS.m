function [c,ceq,gradc,gradceq]=cons_gen_DS(r)

c=sum(r.^2,2)-(1-10^-4);
ceq=[];
gradc=2*sum(r,2);
gradceq=[];

end