clear; clc; close all

Pfs={'Pf_direct','Pf_FORM','Pf_B_CF','Pf_IB_CF','Pf_T_CF',...
    'Pf_B_PF_S','Pf_IB_PF_S','Pf_T_PF_S',...
    'Pf_B_PF_N','Pf_IB_PF_N','Pf_T_PF_N'};
Pfs_var{1}='Pf_direct  = System failure probability (SFP) by direct numerical integration';
Pfs_var{2}='Pf_FORM    = System failure probability (SFP) by FORM approximation';
Pfs_var{3}='Pf_B_CF    = SFP by curvature fitted SORM analysis and Breitung formula';
Pfs_var{4}='Pf_IB_CF   = SFP by curvature fitted SORM analysis and Breitung modified formula';
Pfs_var{5}='Pf_T_CF    = SFP by curvature fitted SORM analysis and Tvedt formula';
Pfs_var{6}='Pf_B_PF_S  = SFP by point fitted SORM analysis with secant iteration and Breitung formula';
Pfs_var{7}='Pf_IB_PF_S = SFP by point fitted SORM analysis with secant iteration and Breitung modified formula';
Pfs_var{8}='Pf_T_PF_S  = SFP by point fitted SORM analysis with secant iteration and Tvedt formula';
Pfs_var{9}='Pf_B_PF_N  = SFP by point fitted SORM analysis with Newton iteration and Breitung formula';
Pfs_var{10}='Pf_IB_PF_N = SFP by point fitted SORM analysis with Newton iteration and Breitung modified formula';
Pfs_var{11}='Pf_T_PF_N  = SFP by point fitted SORM analysis with Newton iteration and Tvedt formula';

Pfs_comp={'Pf_FORM_comp','Pf_B_CF_comp','Pf_IB_CF_comp','Pf_T_CF_comp',...
    'Pf_B_PF_S_comp','Pf_IB_PF_S_comp','Pf_T_PF_S_comp',...
    'Pf_B_PF_N_comp','Pf_IB_PF_N_comp','Pf_T_PF_N_comp'};
Acronmys{1}='FORM    : FORM approximation';
Acronmys{2}='B_CF    : SORM approximation and Breitung formula';
Acronmys{3}='IB_CF   : SORM approximation and Breitung modified formula';
Acronmys{4}='T_CF    : SORM apprixmation and Tvedt formula';
Acronmys{5}='B_PF_S  : SORM approximation with secant iteration and Breitung formula';
Acronmys{6}='IB_PF_S : SORM approximation with secant iteration and Breitung modified formula';
Acronmys{7}='T_PF_S  : SORM approximation with secant iteration and Tvedt formula';
Acronmys{8}='B_PF_N  : SORM approximation with Newton iteration and Breitung formula';
Acronmys{9}='IB_PF_N : SORM approximation with Newton iteration and Breitung modified formula';
Acronmys{10}='T_PF_N  : SORM approximation with Newton iteration and Tvedt formula';

disp('--------------------------------------------------------------');
disp('---                     Welcome to                         ---');
disp('---     Matrix-based System Reliability Analysis (MSR)     ---');
disp('---        Song and Kang (2008, Structural Safety)         ---');
disp('---            Code developed by Bora Gencturk             ---');
disp('--------------------------------------------------------------');
fprintf('\n');
fprintf('\n');
disp('Press Ctrl+C anytime to exit');
fprintf('\n');
fprintf('\n');
input_file_name=input('Please enter the name of the input file \n','s');
switch exist(input_file_name,'file');
    case 2
        switch isempty(strfind(input_file_name,'.m'));
            case 1
                eval(input_file_name);
            otherwise
                eval(input_file_name(1:strfind(input_file_name,'.m')-1));
        end
    otherwise
        fprintf('\n');
        disp('Please check the existance of input file');
        error('Input file name is not avialable in Matlab path');
end
fprintf('\n');
switch exist('sys_def','var');
    case 1
        if (length(sys_def{1})==1 && (abs(sys_def{1})<=1)) || isempty(sys_def{1})==1;
            sys_type='component';
        else
            n_comp=max(abs(sys_def{1}));
            [C]=event_matrix(n_comp);
            [c_sys,sys_type,n_cut_sets]=sys_event(sys_def,C);
        end
        switch sys_type
            case 'component'
                disp('This is a component reliability problem');
                disp('You will be directed to FERUM');
            case {'parallel','series'};
                disp(['This is a ',sys_type,' system reliability problem with '...
                    ,num2str(n_comp),' components']);
            case {'general'}
                disp(['This is a ',sys_type, ' system reliability problem with:']);
                fprintf('%-21s %1d \n','Number of components:',n_comp)
                fprintf('%-21s %1d \n',['Number of ',lower(sys_def{2}),' sets:'],n_cut_sets);
        end
    otherwise
        sys_type='component';
        disp('The variable sys_def is not available in the input file');
        disp('MSR will proceed as a component reliability problem and');
        disp('you will be directed to FERUM');
end
input_check=0;
while any(input_check==[1 2])~=1;
    fprintf('\n');
    input_check=input('Is the above information correct? [1]: Yes, [2]: No \n');
end
switch input_check
    case 1
        switch sys_type
            case 'component'
                ferum
            case {'parallel','series','general'}
                if exist('R','var')==1;
                    R=R+R'; R=R-diag(diag(R))+eye(length(R));                                       
                else
                    fprintf('\n');
                    fprintf(['Correlation coefficient matrix, R, for components does not exist\n',...
                          'MSR will now run component reliability analysis for each component \n']);                    
                    re_comp_anal=0;
                    for i=1:length(gfundata);
                        fprintf('\n');
                        disp(['Reliability Analysis for Component # ',num2str(i)]);
                        disp('--------------------------------------');
                        while re_comp_anal==0;
                            comp_anal_type=0;
                            while any(comp_anal_type==[1 2])~=1;
                                fprintf('\n');
                                comp_anal_type=input('Choose method for component reliability analysis [1]: FORM, [2]: SORM \n');                                
                            end
                            formresults=form(i,probdata,analysisopt,gfundata,femodel,randomfield);
                            Pf_FORM_comp=formresults.pf1; b_FORM_comp=formresults.beta1;
                            alpha_comp=formresults.alpha;
                            if comp_anal_type==2;
                                SORM_method_comp=0;
                                while any(SORM_method_comp==[1 2])~=1;
                                    fprintf('\n');
                                    disp('[1]: Curvature-fitted SORM');
                                    disp('[2]: Point-fitted SORM');
                                    SORM_method_comp=input('Enter the SORM method for component reliability analysis \n');
                                end
                                if SORM_method_comp==2;
                                    point_fitting_method_comp=0;
                                    while any(point_fitting_method_comp==[1 2])~=1;
                                        fprintf('\n');
                                        disp('[1]: Secant iteration method');
                                        disp('[2]: Newton iteration method');
                                        point_fitting_method_comp=input('Enter the iteration method for point-fitted SORM method for component reliabilty analysis \n');
                                    end
                                end
                                switch SORM_method_comp
                                    case 1
                                        [sorm_curfit_results] = sorm_curvature_fitting(i,formresults,probdata,analysisopt,gfundata,femodel,randomfield);
                                        Pf_B_CF_comp=sorm_curfit_results.pf2_breitung; b_B_CF_comp=sorm_curfit_results.beta2_breitung;
                                        Pf_IB_CF_comp=sorm_curfit_results.pf2_breitung_mod; b_IB_CF_comp=sorm_curfit_results.beta2_breitung_mod;
                                        Pf_T_CF_comp=sorm_curfit_results.pf2_tvedt_EI; b_T_CF_comp=sorm_curfit_results.beta2_tvedt_EI;
                                    case 2
                                        switch point_fitting_method_comp
                                            case 1
                                                [sorm_point_fitted_secant_results] = sorm_point_fitted_mod_secant(i,formresults,probdata,analysisopt,gfundata,femodel,randomfield);
                                                Pf_B_PF_S_comp=sorm_point_fitted_secant_results.pf2_breitung; b_B_PF_S_comp=sorm_point_fitted_secant_results.beta2_breitung;
                                                Pf_IB_PF_S_comp=sorm_point_fitted_secant_results.pf2_breitung_mod; b_IB_PF_S_comp=sorm_point_fitted_secant_results.beta2_breitung_mod;
                                                Pf_T_PF_S_comp=sorm_point_fitted_secant_results.pf2_tvedt_EI; b_T_PF_S_comp=sorm_point_fitted_secant_results.beta2_tvedt_EI;
                                            case 2
                                                [sorm_point_fitted_newton_results] = sorm_point_fitted_mod(i,formresults,probdata,analysisopt,gfundata,femodel,randomfield);
                                                Pf_B_PF_N_comp=sorm_point_fitted_newton_results.pf2_breitung; b_B_PF_N_comp=sorm_point_fitted_newton_results.beta2_breitung;
                                                Pf_IB_PF_N_comp=sorm_point_fitted_newton_results.pf2_breitung_mod; b_IB_PF_N_comp=sorm_point_fitted_newton_results.beta2_breitung_mod;
                                                Pf_T_PF_N_comp=sorm_point_fitted_newton_results.pf2_tvedt_EI; b_T_PF_N_comp=sorm_point_fitted_newton_results.beta2_tvedt_EI;
                                        end
                                end                                        
                            end
                            fprintf('\n');
                            disp('Description of acronmys:');
                            disp('---------------------------');
                            disp('Pf      : Component failure probability');
                            disp('b       : Component reliability index');
                            for j=1:length(Acronmys);
                                if exist(Pfs_comp{j},'var')==1;
                                    disp(Acronmys{j});
                                end
                            end
                            disp('---------------------------');
                            fprintf('\n');
                            fprintf('Component failure probabilities and reliability indices\nfrom different integration methods: \n');
                            disp('-------------------------------------------------------------');
                            aval_comp_anal_types=[];
                            for j=1:length(Pfs_comp);
                                if exist(Pfs_comp{j},'var')==1;
                                    aval_comp_anal_types=[aval_comp_anal_types j];
                                    fprintf('%-15s = %-1.5E \n',Pfs_comp{j},eval(Pfs_comp{j}));
                                end
                            end
                            disp('-------------------------------------------------------------');
                            re_comp_anal_ask=0;
                            while any(re_comp_anal_ask==[1 2])~=1;
                                fprintf('\n');
                                re_comp_anal_ask=input('Do you want to perform reliability analysis\nfor this component using another method?\n[1]: Yes, [2]: No \n');
                            end
                            if re_comp_anal_ask==2; re_comp_anal=1; end                            
                        end
                        res_comp_anal=0;
                        while any(res_comp_anal==1:length(aval_comp_anal_types))~=1;
                            fprintf('\n');
                            for j=1:length(aval_comp_anal_types);
                                fprintf('%-s%+2s%-1s%-2s%-50s\n','[',num2str(j),']',':',Acronmys{aval_comp_anal_types(j)});
                            end
                            fprintf('\n');
                            res_comp_anal=input('Choose from one of the above available results for this \ncomponent to be used in system reliability analysis \n');
                        end
                        res_comp_anal=aval_comp_anal_types(res_comp_anal);
                        btf=formresults.beta_sensi_thetaf; [r_btf,c_btf]=size(btf);
                        btf=reshape(btf,1,r_btf*c_btf);
                        btg=formresults.beta_sensi_thetag; [r_btg,c_btg]=size(btg);
                        btg=reshape(btg,1,r_btg*c_btg);
                        J_bt(i,:)=[btf(btf~=0) btg(1:end/2)];
                        tt_b=['b',Pfs_comp{res_comp_anal}(3:end)];
                        p_marg(i)=eval(Pfs_comp{res_comp_anal}); beta(i)=eval(tt_b); alpha(:,i)=alpha_comp;
                        re_comp_anal=0; clear Pf_* b_*
                    end
                    R=alpha'*alpha; R=R-diag(diag(R))+eye(length(R));
                    beta=beta'; p_marg=p_marg';
                    fprintf('\n');
                    disp('-----------------------------------------------');
                    disp('Now proceeding with system reliability analysis');
                    disp('-----------------------------------------------');
                end
                if exist('beta','var')==0;
                    if exist('p_marg','var')==1;
                        beta=-norminv(p_marg);
                    else
                        fprintf('\n');
                        error(['Neither the probabilities nor reliability indices exist ',...
                               'for components, please check the input file']);
                    end
                end
                n=length(R); max_CSRV=ceil((n-1)/2);
                input_CSRV=0; n_CSRV=0.5;
                while input_CSRV==0;
                    fprintf('\n');
                    disp('Notes:');
                    disp('1. Should be a positive integer');
                    disp(['2. Recommended # of CSRV''s is <= ',num2str(max_CSRV)]);
                    disp('3. Direct numerical integration is available up to 3 CSRV''s');
                    disp('4. May be costly for large # of CSRV''s and/or components');                    
                    while (n_CSRV-floor(n_CSRV))~=0 || n_CSRV<=0;
                        fprintf('\n');
                        n_CSRV=input('Enter the number of common source random variables (CSRV) \n');                        
                    end
                    warning off all;
                    [r,R_DS,res_check,iter_results]=gen_DS_solver(R,n_CSRV);
                    fprintf('\n');
                    fprintf('Norm of error = %1.5E \n',iter_results(1));
                    CSRV_ask=0;
                    while any(CSRV_ask==[1 2])~=1;
                        fprintf('\n');
                        CSRV_ask=input('Do you want to change the number of CSRV''s? [1]: Yes, [2]: No \n');
                    end
                    if CSRV_ask==1;
                        input_CSRV=0; n_CSRV=0.5;
                    else
                        input_CSRV=1;
                    end
                end
                
                re_integ_chck=0; conv_i=[];
                while re_integ_chck~=1;
                    integ_method=0; SORM_method=0; point_fitting_method=0; integ_method_chck=0;
                    while (any(integ_method==[1 2 3])~=1) || integ_method_chck~=1;
                        fprintf('\n');
                        disp('[1]: Direct numerical integration');
                        disp('[2]: Integration by FORM');
                        disp('[3]: Integration by SORM');
                        integ_method=input('Enter the integration method \n');
                        if n_CSRV>3 && integ_method==1;
                            fprintf('\n');
                            disp('Direct numerical integration is available up to 3 CSRVs');
                            integ_method_chck=0;
                        else
                            integ_method_chck=1;
                        end
                    end
                    if integ_method==3;
                        while any(SORM_method==[1 2])~=1;
                            fprintf('\n');
                            disp('[1]: Curvature-fitted SORM');
                            disp('[2]: Point-fitted SORM');
                            SORM_method=input('Enter the SORM method \n');
                        end
                        if SORM_method==2;
                            while any(point_fitting_method==[1 2])~=1;
                                fprintf('\n');
                                disp('[1]: Secant iteration method');
                                disp('[2]: Newton iteration method');
                                point_fitting_method=input('Enter the iteration method for point-fitted SORM method \n');
                            end
                        end
                    end
                    fprintf('\n');
                    disp('The following variables are available in your workspace:');
                    disp('-----------------------------------------------------------');
                    disp('r          = Generalized Dunett-Sobel (DS) class correlation coefficients');
                    disp('R_DS       = Generalized Dunett-Sobel (DS) class correlation coefficient matrix');
                    if integ_method==1;
                        integ_method='direct';
                        [Pf_direct]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method);
                    elseif integ_method==2;
                        integ_method='FORM';
                        [Pf_FORM]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method);
                    else
                        integ_method='SORM';
                        if SORM_method==1;
                            SORM_method='curvature fitting';
                            [dummy,Pf_B_CF,Pf_IB_CF,Pf_T_CF]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method,SORM_method);
                        else
                            SORM_method='point fitting';
                            if point_fitting_method==1;
                                point_fitting_method='secant';
                                [dummy2,Pf_B_PF_S,Pf_IB_PF_S,Pf_T_PF_S]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method,SORM_method,point_fitting_method);
                            else
                                point_fitting_method='Newton';
                                [dummy3,Pf_B_PF_N,Pf_IB_PF_N,Pf_T_PF_N]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method,SORM_method,point_fitting_method);
                            end

                        end
                    end
                    for i=1:length(Pfs);
                        if exist(Pfs{i},'var')==1;
                            disp(Pfs_var{i});
                        end
                    end
                    disp('-----------------------------------------------------------');
                    fprintf('\n');
                    disp('Failure probabilities from different integration methods:');
                    disp('-----------------------------------------------------------');
                    for i=1:length(Pfs);
                        if exist(Pfs{i},'var')==1;
                            fprintf('%-10s = %-1.5E \n',Pfs{i},eval(Pfs{i}));
                        end
                    end
                    disp('-----------------------------------------------------------');
                    re_integ=0;
                    while any(re_integ==[1 2])~=1;
                        fprintf('\n');
                        re_integ=input('Do you want to perform integration again using another method? [1]: Yes, [2]: No \n');
                    end
                    if re_integ==1;
                        re_integ_chck=0;
                    else
                        re_integ_chck=1;
                    end
                end
                sens_ask=0;
                if exist('J_bt','var')==1 || exist('J_Pft','var')==1;
                    while any(sens_ask==[1 2])~=1; 
                        fprintf('\n');
                        sens_ask=input('Jacobian is provided in the input file, do you want to perform sensitivity analysis (SA)? \n[1]: Yes, [2]: No \n');
                    end
                    if sens_ask==1;
                        if exist('J_Pft','var')==1 && exist('J_bt','var')==0;
                            J_bt=-inv(diag(normpdf(-beta)))*J_Pft;
                        end
                        input_CSRV_sens=0; n_CSRV_sens=0.5;
                        fprintf('\n');
                        disp('SA can only be performed using direct numerical integration');
                        while input_CSRV_sens==0;
                            while (n_CSRV_sens-floor(n_CSRV_sens))~=0 || n_CSRV_sens<=0 || n_CSRV_sens>3;
                                fprintf('\n');
                                n_CSRV_sens=input('Enter the number of CSRV''s for SA, 1 <= # of CSRV''s <=3 \n');
                            end
                            warning off all;
                            [r_sens,R_DS_sens,res_check_sens,iter_results_sens]=gen_DS_solver(R,n_CSRV_sens);
                            fprintf('\n');
                            fprintf('Norm of error = %1.5E \n',iter_results_sens(1));
                            CSRV_ask_sens=0;
                            while any(CSRV_ask_sens==[1 2])~=1;
                                fprintf('\n');
                                CSRV_ask_sens=input('Do you want to change the number of CSRV''s? [1]: Yes, [2]: No \n');
                            end
                            if CSRV_ask_sens==1;
                                input_CSRV_sens=0; n_CSRV_sens=0.5;
                            else
                                input_CSRV_sens=1;
                            end
                        end
                        [Pf_t]=failure_prob_sens(beta,r_sens,c_sys,J_bt);
                        fprintf('\n');
                        disp('From SA the following variables are available in your workspace:');
                        disp('-------------------------------------------------------------------');
                        disp('r_sens    = Generalized DS class correlation coefficients used for SA');
                        disp('R_DS_sens = Generalized DS class correlation coefficient matrix');
                        disp('Pf_t      = Sensitivity of the system failure probability');
                        disp('-------------------------------------------------------------------');
                        fprintf('\n');
                        disp('Sensitivity of the system failure probability:');
                        disp('-------------------------------------------------------------------');
                        tt='%-6s = ';
                        for i=1:length(Pf_t);
                            if i==length(Pf_t); tt=[tt,'%-10.5E \n']; else tt=[tt,'%-10.5E']; end
                        end
                        fprintf(tt,'Pf_t',Pf_t);
                        disp('-------------------------------------------------------------------');
                    end
                end
        end
    case 2
        fprintf('\n');
        disp('Please check the input file');
end        
fprintf('\n');
disp('Thank you for using MSR :)');
disp('Bye...');
fprintf('\n');



