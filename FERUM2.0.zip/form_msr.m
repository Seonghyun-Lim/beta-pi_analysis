function formresults = form_msr(c_sys,beta,r,probdata,analysisopt)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Finite Element Reliability using Matlab, FERUM, Version 3.0       %
%                                                                   %
% This program is free software; you can redistribute it and/or     %
% modify it under the terms of the GNU General Public License       %
% as published by the Free Software Foundation; either version 2    %
% of the License, or (at your option) any later version.            %
%                                                                   %
% This program is distributed in the hope that it will be useful,   %
% but WITHOUT ANY WARRANTY; without even the implied warranty of    %
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the     %
% GNU General Public License for more details.                      %
%                                                                   %
% A copy of the GNU General Public License is found in the file     %
% <gpl.txt> following this collection of program files.             %
%                                                                   %
% Developed under the sponsorship of the Pacific                    %
% Earthquake Engineering (PEER) Center.                             %
%                                                                   %
% For more information, visit: http://www.ce.berkeley.edu/~haukaas  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

marg      = probdata.marg;
R         = probdata.correlation;

i_max     = analysisopt.ig_max;
e1        = analysisopt.e1;
e2        = analysisopt.e2;
step_code = analysisopt.step_code;

% Compute corrected correlation coefficients
Ro = mod_corr( probdata, R );

% Cholesky decomposition
Lo = (chol(Ro))';
iLo = inv(Lo);

% Compute starting point for the algorithm
x = ( marg(:,4) );
u = x_to_u(x,probdata,iLo);

% Set parameters for the iterative loop
i = 1;         % Initialize counter.
conv_flag = 0; % Convergence is achieved when this flag is set to 1.

% Perform iterative loop to find the design point
while conv_flag == 0;

    % Transformation from u to x space
    x = u_to_x(u,probdata,Lo);
    J_u_x = jacobian(x,u,probdata,Lo,iLo);
    J_x_u = inv(J_u_x);

    % Evaluate limit-state function and its gradient
    [G,grad_g]=msr_lsf(x,c_sys,beta,r);
    grad_G = (grad_g * J_x_u)';
    Recorded_grad_G_values(:,i) = grad_G;
    Recorded_G_function_values(i) = G;

    % Set scale parameter Go and inform about struct. resp.
    if i == 1
        Go = G;
    end

    % Compute alpha vector
    alpha = -grad_G / norm(grad_G);

    % Check convergence
    if ( (abs(G/Go)<e1) && (norm(u-alpha'*u*alpha)<e2) ) || i==i_max
        conv_flag = 1;
    end

    % Take a step if convergence is not achieved
    if conv_flag == 0;

        % Determine search direction
        d = search_dir(G,grad_G,u);

        % Determine step size
        if step_code == 0
            il_max = analysisopt.il_max;
            c = ( norm(u) / norm(grad_G) ) * 2 + 10;
            merit = 0.5 * (norm(u))^2 + c * abs(G);
            trial_step_size = 1;
            trial_u = u + trial_step_size * d;
            trial_x = u_to_x(trial_u,probdata,Lo);
            [trial_G,dummy]=msr_lsf(trial_x,c_sys,beta,r);
            merit_new = 0.5 * (norm(trial_u))^2 + c * abs(trial_G);

            i = 1;
            while ( merit_new > merit ) && ( i < il_max + 1 )
                trial_step_size = trial_step_size * 0.5;
                trial_u = u + trial_step_size * d;
                [ trial_x ] = u_to_x(trial_u,probdata,Lo);
                [trial_G,dummy]=msr_lsf(trial_x,c_sys,beta,r);
                merit_new = 0.5 * (norm(trial_u))^2 + c * abs(trial_G);

                i = i + 1;
            end
            step = trial_step_size;
        else
            step = step_code;
        end
        Recorded_step_size_values(i) = step;

        % Determine new trial point
        u_new = u + step * d;

        % Prepare for a new round in the loop
        u = u_new;
        i = i + 1;

    end
end

if i ~= i_max

    %  Post-processing
    formresults.iter= i;                                                   % Number_of_iterations
    formresults.beta1= alpha' * u;                                          % Reliability_index_beta
    formresults.pf1= ferum_cdf(1,-formresults.beta1,0,1);                   % Failure_probability_pf1
    formresults.dsptu= u;                                                  % Design_point_u_star
    formresults.dsptx= x';                                                 % Design_point_in_original_space
    formresults.alpha= alpha;                                              % Alpha_vector

    D_prime = diag(diag(   sqrt( J_x_u * J_x_u' )    ));                   % (intermediate computation)

    formresults.imptg =(alpha'*J_u_x*D_prime/norm(alpha'*J_u_x*D_prime))'; % Importance_vector_gamma
    formresults.gfcn = Recorded_G_function_values;
    formresults.grad_gfunc = Recorded_grad_G_values;
    formresults.stpsz = Recorded_step_size_values;

else
    disp('Maximum number of iterations was reached before convergence.');
end
