function [G,grad_g]=msr_lsf(s,c_sys,beta,r)

p_marginals=normcdf((-beta-r*s(1:end-1))./sqrt(1-sum(r.^2,2)));
p=prob_vector(p_marginals);
G=s(end)-norminv(c_sys'*p);
for i=1:length(beta);
    p_marg_mod=p_vector_mod(p_marginals,i);
    P_h(:,i)=p_marg_mod;
end
dP_ds=-diag(normpdf((-beta-r*s(1:end-1))./sqrt(1-sum(r.^2,2)))./...
    sqrt(1-sum(r.^2,2)))*r;
dp_ds=P_h*dP_ds;
grad_g=[-c_sys'*dp_ds*1/(normpdf(s(end)-G)) 1];

end

