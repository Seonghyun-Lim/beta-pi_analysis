function [P,cov,N] = scis(a,b,m,C,Nmax,Nmin,covmax)
%SCIS        Sequential Conditioned Importance Sampling
%
%   [P,cov,N] = scis(a,b,m,C,Nmax,Nmin,covmax)
%  
%   Evaluates the probability of multinormal variable
%   in the rectangular domain by SCIS
%

%    Output: - P       = Estimate of probability of multinormal variable N(m,C)
%                        in the n-dimensional rectangular domain [a_k,b_k]
%            - cov     = Coefficient of variation of estimate P
%            - N       = Total number of SCIS trials
%

%    Input:  - a       = Lower bounds
%            - b       = Upper bounds
%            - m       = Mean vector
%            - C       = Covariance matrix
%            - Nmax    = Maximum trial number of SCIS
%            - Nmin    = Minimum trial number of SCIS
%            - covmax  = Maximum coefficent of variation

%    Required M-files:
%            - FERUM/ferum_cdf.m    = Calculate CDF of designated distn.
%            - FERUM/inv_norm_cdf   = Calculate inverse of normal CDF
%
%   "Multinormal Probability by Sequential Conditioned Importance Sampling"
%      by R.Ambartzumian, A.Der Kiureghian, V.Ohanian, and H.Sukiasian
%      Probabilistic Engineering Mechanics, Vol.13, No.4, pp.299-308, 1998.

% n : Number of random variables
n = length(a);

% Preallocating
% for optimized dll(MEX) file(-i option), all arrays should be preallocated
% and should not grow dynamically.

Dk = zeros(n,n);
d = zeros(n,n);
y = zeros(1,Nmax);
x = zeros(1,n);

% Preprocessings
% d : Matrix containing parts of inverse of covariance matrix 
%     (Note) d(k,1:k) - k-th row of inverse matrix of C(1:k,1:k)
for ii = 1:n,
      Dk(1:ii,1:ii) = inv(C(1:ii,1:ii));
      for j = 1:ii,
      d(ii,j) = Dk(ii,j);   
   end
end


% ICIS algorithm 
% y    : Product of probabilities
% sumy : Sum of products y
% P    : Estimate of probability (sumy/N)
% em   : Mean of conditional multinormal distribution
% dd   : Standard deviation of conditional multinormal distribution
% x    : Sampled value for each random variable

%------- Initializations -------%
sumy = 0;
cov = inf;
P = 0;

for ii = 1:Nmax,
   %------- Calculate y at i-th trial -------%
   y(ii) = 1;
   
   %------- Calculate probability of k-th variable -------%
   for k = 1:n,
      
      %------- Mean and s.d. for k-th variable -------%
      em = m(k);         % mean of conditional distn for k=1
      dd = 1/sqrt(d(k,k)); 
      %------- Mean of conditional distn (for k~=1) -------%
      if k~=1,
         for j = 1:k-1,
            sm = d(k,j)*(x(j)-m(j))/d(k,k);
            em = em - sm;
         end
      end
      
      %------- Stadardization -------%
      za = (a(k)-em)/dd;
      zb = (b(k)-em)/dd;
      
      %------- Conditional cumulative probability -------%
      za = ferum_cdf(1,za,0,1);
      zb = ferum_cdf(1,zb,0,1);
      y(ii) = y(ii)*(zb-za);
      
      %------- Sample a random value x_k -------%
      zz = inv_norm_cdf((zb-za)*rand(1)+za);
      x(k) = dd*zz + em;
      
   end
   
   %------- Postprocessings at i-th trial -------%
   sumy = sumy + y(ii); % Sum of y's upto i-trials
   N = ii;              % Number of trials at present
   P = sumy / N;        % Estimate of probability
   
   %------- Calculation of c.o.v. of estimate P -------%
   if (ii>= Nmin &  P ~= 0), % Do not stop until N > Nmin
      cov = norm(y(1,1:N)-P*ones(1,N))/N/P; 
   end
   if cov <= covmax,
      break
   end
end