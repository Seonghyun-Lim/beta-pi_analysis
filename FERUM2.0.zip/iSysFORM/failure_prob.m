function [formresults]=failure_prob(beta,r,c_sys,sys_type,sys_def,integ_method,varargin)

m=size(r,2);
if isempty(varargin)~=1;
    SORM_method=varargin{1};
    if strcmp(SORM_method,'point fitting')==1;
        point_fitting_method=varargin{2};
    end
end
        
switch integ_method
    case 'direct'
        tol=10^-9; int_lb=-5; int_ub=5;
        switch m
            case 1
                Pf=quad(@(x)integrnd(beta,r,c_sys,sys_type,x),...
                    int_lb,int_ub,tol);
            case 2
                Pf=dblquad(@(x,y)integrnd(beta,r,c_sys,sys_type,x,y),...
                    int_lb,int_ub,int_lb,int_ub,tol);
            case 3
                Pf=triplequad(@(x,y,z)integrnd(beta,r,c_sys,sys_type,...
                    x,y,z),int_lb,int_ub,int_lb,int_ub,int_lb,int_ub,tol);
        end
        if strcmp(sys_type,'series')==1;
            Pf=1-Pf;
        end
    case {'FORM','SORM'}
        [probdata,analysisopt]=create_input(m);
        formresults=form_msr(c_sys,beta,r,probdata,analysisopt);
        if isempty(formresults)==1;
            error(['FORM/SORM can not solve given problem (issue of convergence),',...
                ' please try direct numerical integration (or decreasing the # of CSRV''s)']);
        end
%         Pf.pf =formresults.pf1;
%         Pf.dsptx =formresults.dsptx;
        if strcmp(integ_method,'SORM')==1;
            switch SORM_method
                case 'curvature fitting'
                    sorm_curfit_results=sorm_curvature_fitting_msr(c_sys,beta,r,formresults,probdata);
                    Pf_Breitung=sorm_curfit_results.pf2_breitung;
                    Pf_imp_Breitung=sorm_curfit_results.pf2_breitung_mod;
                    Pf_Tvedt=sorm_curfit_results.pf2_tvedt_EI;
                case 'point fitting'
                    switch point_fitting_method
                        case 'secant'
                            sorm_point_fitted_secant_results=sorm_point_fitted_mod_secant_msr(c_sys,beta,r,formresults,probdata);
                            Pf_Breitung=sorm_point_fitted_secant_results.pf2_breitung;
                            Pf_imp_Breitung=sorm_point_fitted_secant_results.pf2_breitung_mod;
                            Pf_Tvedt=sorm_point_fitted_secant_results.pf2_tvedt_EI;
                        case 'Newton'
                            sorm_point_fitted_newton_results=sorm_point_fitted_mod_msr(c_sys,beta,r,formresults,probdata);
                            Pf_Breitung=sorm_point_fitted_newton_results.pf2_breitung;
                            Pf_imp_Breitung=sorm_point_fitted_newton_results.pf2_breitung_mod;
                            Pf_Tvedt=sorm_point_fitted_newton_results.pf2_tvedt_EI;
                    end
            end
        end
end

if strcmpi(sys_type,'general')==1 && strcmpi(sys_def{2},'link')==1;
    Pf=1-Pf;
    if strcmpi(integ_method,'SORM')==1;
        Pf_Breitung=1-Pf_Breitung; Pf_imp_Breitung=1-Pf_imp_Breitung; Pf_Tvedt=1-Pf_Tvedt;        
    end
end
if isempty(varargin)~=1;
    varargout={Pf_Breitung,Pf_imp_Breitung,Pf_Tvedt};
end

end
