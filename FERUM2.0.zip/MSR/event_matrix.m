function [C]=event_matrix(n_events)

for i=1:n_events;
    if i==1;
        C=[1; 0];
    else
        C=[C ones(length(C),1); C zeros(length(C),1)];
    end
end

end