function [probdata,analysisopt]=create_input(m)

clear probdata analysisopt results 

for i=1:m+1;
    probdata.marg(i,:)=[1 0 1 zeros(1,6)];    
end

probdata.correlation=eye(m+1);
probdata.parameter=distribution_parameter(probdata.marg);
analysisopt.ig_max=250;
analysisopt.il_max=5;
analysisopt.e1=0.001;
analysisopt.e2=0.001;
analysisopt.step_code=1;
analysisopt.sim_point='dspt';
analysisopt.stdv_sim=1;
analysisopt.num_sim=100000;
analysisopt.target_cov=0.0125;
% gfundata(1).evaluator='basic';
% gfundata(1).type='msr';
% gfundata(1).parameter='no';

end

