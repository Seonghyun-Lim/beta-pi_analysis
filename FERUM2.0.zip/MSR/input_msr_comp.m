sys_def={-2}; 

probdata.marg(1,:) =  [ 2   250    250*0.3     250    0 0 0 0 0];
probdata.marg(2,:) =  [ 2   125    125*0.3     125    0 0 0 0 0];
probdata.marg(3,:) =  [ 2   2500   2500*0.2    2500   0 0 0 0 0];
probdata.marg(4,:) =  [ 2   40000   40000*0.1  40000  0 0 0 0 0];

probdata.correlation = [1.0 0.5 0.3 0.0;
                        0.5 1.0 0.3 0.0;
                        0.3 0.3 1.0 0.0;
                        0.0 0.0 0.0 1.0];
                      
probdata.parameter = distribution_parameter(probdata.marg);
                      
analysisopt.ig_max    = 100;
analysisopt.il_max    = 5;
analysisopt.e1        = 0.001;
analysisopt.e2        = 0.001; 
analysisopt.step_code = 1;
analysisopt.grad_flag = 'DDM';
analysisopt.sim_point = 'dspt';
analysisopt.stdv_sim  = 1;
analysisopt.num_sim   = 100000;
analysisopt.target_cov = 0.0125;

gfundata(1).evaluator = 'basic';
gfundata(1).type = 'expression';
gfundata(1).parameter = 'yes'; 
gfundata(1).thetag = 2; 
gfundata(1).expression = ['1-x(1)/0.030/x(4)-x(2)/0.015/x(4)-'...
    '(x(3)/0.190/x(4))^gfundata(1).thetag(1)'];
gfundata(1).dgdq = { '-1/0.030/x(4)' ;
                     '-1/0.015/x(4)';
                     ['-gfundata(1).thetag(1)*(x(3)/0.190/x(4))^'...
                     '(gfundata(1).thetag(1)-1)/0.190/x(4)']; 
                     ['x(1)/0.030/x(4)^2+x(2)/0.015/x(4)^2+'...
                     'gfundata(1).thetag(1)*(x(3)/0.190)^gfundata(1).'...
                     'thetag(1)*x(4)^(-gfundata(1).thetag(1)-1)']};
gfundata(1).dgthetag = {['-log(x(3)/0.190/x(4))*(x(3)/0.190/x(4))^'...
    'gfundata(1).thetag(1)']};

gfundata(2).evaluator = 'basic';
gfundata(2).type = 'expression';
gfundata(2).parameter = 'yes'; 
gfundata(2).thetag = 2; 
gfundata(2).expression = ['1-x(1)/0.030/x(4)-x(2)/0.015/x(4)-'...
    '(x(3)/0.190/x(4))^gfundata(1).thetag(1)'];
gfundata(2).dgdq = { '-1/0.030/x(4)' ;
                     '-1/0.015/x(4)';
                     ['-gfundata(1).thetag(1)*(x(3)/0.190/x(4))^'...
                     '(gfundata(1).thetag(1)-1)/0.190/x(4)']; 
                     ['x(1)/0.030/x(4)^2+x(2)/0.015/x(4)^2+'...
                     'gfundata(1).thetag(1)*(x(3)/0.190)^gfundata(1).'...
                     'thetag(1)*x(4)^(-gfundata(1).thetag(1)-1)']};
gfundata(2).dgthetag = {['-log(x(3)/0.190/x(4))*(x(3)/0.190/x(4))^'...
    'gfundata(1).thetag(1)']};

femodel = 0;
randomfield.mesh = 0;