clear all
inputfile1

[formresults1] = form(1,probdata,analysisopt,gfundata,femodel,randomfield);
[formresults2] = form(2,probdata,analysisopt,gfundata,femodel,randomfield);

% [sorm_curfit_results1] = sorm_curvature_fitting_temp(1,formresults1,probdata,analysisopt,gfundata,femodel,randomfield);
% [sorm_curfit_results2] = sorm_curvature_fitting_temp(2,formresults2,probdata,analysisopt,gfundata,femodel,randomfield);

rho_FORM = formresults1.alpha'*formresults2.alpha;
beta = [formresults1.beta1; formresults2.beta1];
% beta = [sorm_curfit_results1.beta2_breitung; sorm_curfit_results2.beta2_breitung]; 

r = [sqrt(rho_FORM); sqrt(rho_FORM)]; %DS for two components...

% c_sys = [1 0 0 0]';
% sys_type = 'parallel';
% sys_def = {2};

c_sys = [1 1 1 0]';
sys_type = 'series';
sys_def = {-2};

[formresults_s]=failure_prob(beta,r,c_sys,sys_type,sys_def,'FORM');
s_star(1) = formresults_s.dsptx(1);
pf(1) = formresults_s.pf1;
rho_v(1) = rho_FORM;
bv(1,1) = beta(1);
bv(1,2) = beta(2);

% OK... now I found s_star and now it's time to find correlation given
% s_star

for i = 2:30,
A = [formresults1.alpha'; formresults2.alpha'];
Q = [sqrt(1-r(1)^2) 0; 0 sqrt(1-r(1)^2)];
R = [r(1); r(1)];

M = inv(A)*R*s_star(i-1);
S = inv(A)*Q*(inv(A)*Q)';
s1 = sqrt(S(1,1));
s2 = sqrt(S(2,2));
r12 = S(1,2)/s1/s2;
% 
% s_s_range=[-5:0.1:10];
% ustar1 = formresults1.dsptu;
% ustar2 = formresults2.dsptu;
% ustar1 = inv(A)*Q*ustar1+inv(A)*R*s_star(1);
% ustar2 = inv(A)*Q*ustar2+inv(A)*R*s_star(1);
% alpha1 = ustar1/norm(ustar1);
% alpha2 = ustar2/norm(ustar2);
% r = sqrt(alpha1'*alpha2);
% beta1 = norm(ustar1);
% beta2 = norm(ustar2);
% s_range=[-5:0.1:10];
% p_fo = 1-(1-normcdf((-beta1+r*s_range)/sqrt(1-r^2))).*(1-normcdf((-beta2+r*s_range)/sqrt(1-r^2)));
% trapz(s_range,p_fo.*normpdf(s_range))

probdata_n.marg(1,:) =  [ 1 M(1) s1 M(1) 0 0 0 0 0];
probdata_n.marg(2,:) =  [ 1 M(2) s2 M(2) 0 0 0 0 0];
probdata_n.correlation = [1 r12; r12 1];
probdata_n.parameter = distribution_parameter(probdata.marg);

[formresults1] = form(1,probdata_n,analysisopt,gfundata,femodel,randomfield);
% [sorm_curfit_results1] = sorm_curvature_fitting(1,formresults1,probdata_n,analysisopt,gfundata,femodel,randomfield);
[formresults2] = form(2,probdata_n,analysisopt,gfundata,femodel,randomfield);
% [sorm_curfit_results2] = sorm_curvature_fitting(2,formresults2,probdata_n,analysisopt,gfundata,femodel,randomfield);

rho_FORM = formresults1.alpha'*formresults2.alpha;
rho_v(i) = rho_FORM;
r = [sqrt(rho_FORM); sqrt(rho_FORM)];
beta = [formresults1.beta1; formresults2.beta1];
%bv(i,:) = beta';

% beta = [sorm_curfit_results1.beta2_breitung; sorm_curfit_results2.beta2_breitung]; 
%normcdf([-beta; -beta])'

[formresults_s]=failure_prob(beta,r,c_sys,sys_type,sys_def,'FORM');
s_star(i) = formresults_s.dsptx(1);
pf(i) = formresults_s.pf1;

end
[ rho_v' s_star' pf']
bv
sorm_curfit_results=sorm_curvature_fitting_msr(c_sys,beta,r,formresults_s,probdata);
Pf_Breitung=sorm_curfit_results.pf2_breitung
Pf_imp_Breitung=sorm_curfit_results.pf2_breitung_mod
Pf_Tvedt=sorm_curfit_results.pf2_tvedt_EI
